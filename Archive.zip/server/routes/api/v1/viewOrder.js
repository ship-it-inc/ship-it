import { Router } from 'express';

import ViewOrder from '../../../controllers/orderHistory';
import JWTHelper from '../../../helpers/jwt';

const viewOrderRouter = Router();


viewOrderRouter.get('/user/history',
  JWTHelper.authenticateUser,
  ViewOrder.viewOrderHistory);


export default viewOrderRouter;
