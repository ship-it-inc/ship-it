export const SUBSCRIBER = 'subscriber';
export const ADMIN = 'admin';

export const ORDER_AMOUNT = {
  withPlate: process.env.PRICE_WITH_PLATE,
  withoutPlate: process.env.PRICE_WITHOUT_PLATE
};
