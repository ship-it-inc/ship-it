import models from '../models';


/**
* @description class will implement CRUD functionalities for articles
*
* @class Orders
*/
class ViewOrders {
  /**
   * @param {object} req - Request sent to the route
   * @param {object} res - Response sent from the controller
   * @param {object} next - Error handler
   * @returns {object} - object representing response message
   */
  static async viewOrderHistory(req, res, next) {
    console.log(req.user.id);
    const userId = req.user.id;
    const { Order } = models;
    try {
      const viewOrderHistory = await Order.findAll({
        where: { userId }
      });
      console.log(viewOrderHistory);
      if (!viewOrderHistory) {
        return res.status(404).send({
          success: false,
          message: 'You currently have not order history'
        });
      }
      return res.status(200).send({
        success: true,
        message: 'All reports successfully returned',
        viewOrderHistory
      });
    } catch (error) {
      return next(error);
    }
  }
}

export default ViewOrders;
